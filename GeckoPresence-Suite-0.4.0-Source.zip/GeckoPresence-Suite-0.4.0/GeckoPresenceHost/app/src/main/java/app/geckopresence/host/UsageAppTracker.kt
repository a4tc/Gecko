package app.geckopresence.host

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import app.geckopresence.host.core.AppActivityRules

data class SelectableApp(val packageName: String, val label: String)

/**
 * Low-frequency foreground-package observer. It retains only the current package in memory;
 * no usage history is written to disk. It reports a package only when the user allow-listed it.
 */
class UsageAppTracker(
    context: Context,
    private val allowedPackages: Set<String>,
    private val onForegroundPackageChanged: (String?) -> Unit,
) {
    private val appContext = context.applicationContext
    private val usageStats = appContext.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastQueryTime = System.currentTimeMillis() - INITIAL_LOOKBACK_MS
    private var foregroundPackage: String? = null
    private var lastReportedPackage: String? = null

    private val pollTask = object : Runnable {
        override fun run() {
            if (!running) return
            pollForegroundPackage()
            if (running) handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    fun start() {
        if (running) return
        running = true
        lastQueryTime = System.currentTimeMillis() - INITIAL_LOOKBACK_MS
        handler.post(pollTask)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(pollTask)
        foregroundPackage = null
        if (lastReportedPackage != null) {
            lastReportedPackage = null
            onForegroundPackageChanged(null)
        }
    }

    private fun pollForegroundPackage() {
        if (!hasUsageAccess(appContext)) {
            report(null)
            return
        }

        val now = System.currentTimeMillis()
        val begin = maxOf(0L, lastQueryTime, now - MAX_LOOKBACK_MS)
        try {
            val events = usageStats.queryEvents(begin, now)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                    event.eventType == UsageEvents.Event.SCREEN_NON_INTERACTIVE
                ) {
                    foregroundPackage = null
                    continue
                }
                val packageName = event.packageName ?: continue
                when {
                    isResumedEvent(event.eventType) -> {
                        foregroundPackage = packageName.takeIf(::isAllowedPackage)
                    }
                    isPausedEvent(event.eventType) && foregroundPackage == packageName -> foregroundPackage = null
                }
            }
            lastQueryTime = maxOf(begin, now - OVERLAP_MS)
            report(foregroundPackage)
        } catch (_: SecurityException) {
            report(null)
        } catch (_: RuntimeException) {
            // OEM UsageStats implementations can temporarily reject a query; preserve the last state.
        }
    }


    private fun isAllowedPackage(packageName: String): Boolean {
        if (packageName !in allowedPackages || packageName == appContext.packageName) return false
        val appInfo = runCatching { appContext.packageManager.getApplicationInfo(packageName, 0) }.getOrNull()
            ?: return false
        val label = runCatching { appContext.packageManager.getApplicationLabel(appInfo).toString() }
            .getOrDefault(packageName)
        return AppActivityRules.isSelectableApp(packageName, label, appContext.packageName)
    }

    private fun report(packageName: String?) {
        if (packageName == lastReportedPackage) return
        lastReportedPackage = packageName
        onForegroundPackageChanged(packageName)
    }

    private fun isResumedEvent(type: Int): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        type == UsageEvents.Event.ACTIVITY_RESUMED
    } else {
        @Suppress("DEPRECATION")
        type == UsageEvents.Event.MOVE_TO_FOREGROUND
    }

    private fun isPausedEvent(type: Int): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        type == UsageEvents.Event.ACTIVITY_PAUSED || type == UsageEvents.Event.ACTIVITY_STOPPED
    } else {
        @Suppress("DEPRECATION")
        type == UsageEvents.Event.MOVE_TO_BACKGROUND
    }

    companion object {
        private const val POLL_INTERVAL_MS = 3_000L
        private const val INITIAL_LOOKBACK_MS = 60_000L
        private const val MAX_LOOKBACK_MS = 5 * 60_000L
        private const val OVERLAP_MS = 3_000L

        fun hasUsageAccess(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            return appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName,
            ) == AppOpsManager.MODE_ALLOWED
        }

        fun selectableApps(context: Context): List<SelectableApp> {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val packageManager = context.packageManager
            val resolved = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                packageManager.queryIntentActivities(intent, 0)
            }
            return resolved.mapNotNull { info ->
                val appInfo = info.activityInfo?.applicationInfo ?: return@mapNotNull null
                val label = runCatching { packageManager.getApplicationLabel(appInfo).toString() }
                    .getOrDefault(appInfo.packageName)
                if (!AppActivityRules.isSelectableApp(appInfo.packageName, label, context.packageName)) return@mapNotNull null
                // Any launchable app is eligible unless the explicit privacy denylist blocks it.
                // This prevents the picker from silently hiding ordinary system media or utility apps.
                SelectableApp(appInfo.packageName, label)
            }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
        }
    }
}
