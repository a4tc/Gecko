# Feature roadmap

The phrase “PreMiD-like” is a target, not a statement that this build already has full feature parity. GPB uses a clean-room activity adapter architecture and adds Android foreground-app detection.

| Capability | 0.4.0 source status | Remaining work |
|---|---|---|
| Active browser tab only | Implemented | Device/browser regression tests |
| YouTube playback | Existing detector retained | Verify current Firefox Android API behaviour |
| Generic HTML5 media state | Implemented | Cross-origin player test matrix |
| IDLix title heuristic | Implemented | Verify exact mirror/player DOM; add fixture per mirror |
| Per-domain browser permission | Implemented | Test on Firefox stable, Nightly and Tor separately |
| Android foreground app tracking | Implemented | Verify Samsung One UI event sequence and battery behaviour |
| Searchable Android allowlist | Implemented | Device usability review |
| Privacy denylist | Implemented as conservative heuristic | Maintain package/domain corpus and regression tests |
| Per-app custom name/details/state | Existing feature retained | Add import/export presets |
| One Android APK | Implemented in source architecture | CI APK build and on-device test required |
| XPI export from APK | Implemented; output is unsigned | Mozilla AMO signing workflow and signed-XPI install verification |
| Discord Social SDK adapter | Existing conditional native integration | Obtain approved official AAR; confirm use eligibility; run real SDK build and OAuth test |
| Registered Discord image assets | Not implemented | Add app asset registry and native SDK integration |
| Discord buttons / deep links | Not implemented | Add allowlisted HTTPS links and click behaviour |
| Rich party / secrets / custom timestamps | Not implemented | Implement only where official SDK and user consent support it |
| True embedded GeckoView browser | Not included | Separate product mode; it is not a Tor Browser replacement |
| Native media title adapters | Not implemented | Use documented per-app APIs only; no Notification Listener or Accessibility scraping |

## Release gates

A release is not considered complete until:

- the Android APK builds successfully on GitHub Actions;
- app picker works on the target Samsung Android 14 device;
- foreground events correctly switch between two allowed apps;
- sensitive apps remain unselectable and are rejected again at runtime;
- Firefox grants one domain permission and media state/title work on an actual media page;
- the generated XPI is signed through AMO before a normal Firefox install;
- the SDK AAR build is compiled and tested only after Discord has approved the application;
- Discord presence is visibly published and cleared on stop/disconnect.
