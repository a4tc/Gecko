import { createActivityEvent, displayNameForHost, isMessageFromActiveTab, isSensitiveHost, selectActiveTab, } from './core/activity.js';
import { permissionPatternForUrl } from './core/site-permissions.js';
const BRIDGE_BASE_URL = 'http://127.0.0.1:32145';
const BRIDGE_TIMEOUT_MS = 5000;
let bridgeQueue = Promise.resolve({
    ok: true,
    state: 'idle',
    message: 'No bridge request has been made.',
});
function isMediaState(value) {
    return ['playing', 'paused', 'ended', 'unknown'].includes(String(value));
}
function isMediaMessage(value) {
    if (!value || typeof value !== 'object')
        return false;
    const message = value;
    return message.type === 'MEDIA_STATE'
        && ['playing', 'paused', 'ended', 'unknown'].includes(String(message.state))
        && (message.pageTitle === undefined || typeof message.pageTitle === 'string');
}
function isBridgeSettingsMessage(value) {
    if (!value || typeof value !== 'object')
        return false;
    const message = value;
    return message.type === 'BRIDGE_SETTINGS_UPDATED' || message.type === 'BRIDGE_SYNC_NOW';
}
function sameActivity(left, right) {
    if (left === null || right === null)
        return left === right;
    return left.source === right.source
        && left.details === right.details
        && left.state === right.state
        && left.mediaState === right.mediaState
        && left.pageTitle === right.pageTitle;
}
function toBridgePayload(activity) {
    return {
        source: activity.source,
        name: displayNameForHost(activity.source),
        details: activity.details,
        state: activity.pageTitle,
        mediaState: activity.mediaState === 'unknown' ? 'browsing' : activity.mediaState,
        startTimestamp: Math.floor(activity.occurredAt / 1000),
    };
}
async function saveBridgeStatus(result) {
    await browser.storage.local.set({
        bridgeStatus: {
            ...result,
            checkedAt: Date.now(),
        },
    });
    return result;
}
async function syncToAndroidHost(activity) {
    const settings = await browser.storage.local.get(['bridgeEnabled', 'bridgeKey']);
    if (settings.bridgeEnabled !== true) {
        return saveBridgeStatus({
            ok: false,
            state: 'disabled',
            message: 'Android bridge is disabled in extension settings.',
        });
    }
    const bridgeKey = typeof settings.bridgeKey === 'string' ? settings.bridgeKey.trim() : '';
    if (!bridgeKey) {
        return saveBridgeStatus({
            ok: false,
            state: 'pairing-required',
            message: 'Copy the pairing key from GeckoPresenceHost and save it in this extension.',
        });
    }
    const isClear = activity === null;
    const endpoint = isClear ? '/v1/clear' : '/v1/activity';
    const body = isClear ? '{}' : JSON.stringify(toBridgePayload(activity));
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), BRIDGE_TIMEOUT_MS);
    try {
        const response = await fetch(`${BRIDGE_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-GPB-Key': bridgeKey,
            },
            body,
            cache: 'no-store',
            credentials: 'omit',
            referrerPolicy: 'no-referrer',
            signal: controller.signal,
        });
        if (response.ok) {
            return saveBridgeStatus({
                ok: true,
                state: 'connected',
                message: isClear ? 'Activity cleared on Android host.' : 'Activity delivered to Android host.',
                httpStatus: response.status,
            });
        }
        if (response.status === 401) {
            return saveBridgeStatus({
                ok: false,
                state: 'pairing-invalid',
                message: 'Android host rejected the pairing key. Copy it again from the host app.',
                httpStatus: response.status,
            });
        }
        return saveBridgeStatus({
            ok: false,
            state: 'host-error',
            message: `Android host rejected the request (HTTP ${response.status}).`,
            httpStatus: response.status,
        });
    }
    catch (error) {
        const timedOut = error instanceof Error && error.name === 'AbortError';
        return saveBridgeStatus({
            ok: false,
            state: 'unreachable',
            message: timedOut
                ? 'Android host did not respond within five seconds.'
                : 'Cannot reach Android host. Keep GeckoPresenceHost running with the bridge listening.',
        });
    }
    finally {
        clearTimeout(timeoutId);
    }
}
function queueBridgeSync(activity) {
    const operation = bridgeQueue.then(() => syncToAndroidHost(activity), () => syncToAndroidHost(activity));
    bridgeQueue = operation.catch(() => ({
        ok: false,
        state: 'error',
        message: 'Bridge synchronization failed.',
    }));
    return operation;
}
async function syncStoredActivity() {
    const stored = await browser.storage.local.get('currentActivity');
    const activity = (stored.currentActivity ?? null);
    return queueBridgeSync(activity);
}
async function storeIfChanged(next, tabId) {
    const stored = await browser.storage.local.get(['currentActivity', 'currentTabId']);
    const current = (stored.currentActivity ?? null);
    if (sameActivity(current, next) && stored.currentTabId === tabId)
        return;
    await browser.storage.local.set({ currentActivity: next, currentTabId: tabId ?? null });
    await queueBridgeSync(next);
}
async function getCurrentActiveTab() {
    const tabs = await browser.tabs.query({ active: true, currentWindow: true });
    return selectActiveTab(tabs);
}
async function injectGenericMediaDetector(tab) {
    if (!tab.url)
        return;
    let parsed;
    try {
        parsed = new URL(tab.url);
    }
    catch {
        return;
    }
    if (isSensitiveHost(parsed.hostname))
        return;
    const originPattern = permissionPatternForUrl(tab.url);
    if (!originPattern)
        return;
    try {
        const hasPermission = await browser.permissions.contains({ origins: [originPattern] });
        if (!hasPermission)
            return;
        await browser.tabs.executeScript(tab.id, {
            file: 'content/generic-media.js',
            runAt: 'document_idle',
            allFrames: true,
        });
    }
    catch {
        // Restricted pages, permission removal and unsupported injection targets are ignored.
    }
}
async function refreshActiveActivity() {
    const tab = await getCurrentActiveTab();
    if (!tab) {
        await storeIfChanged(null);
        return;
    }
    await injectGenericMediaDetector(tab);
    let mediaState = 'unknown';
    let mediaTitle;
    try {
        const response = await browser.tabs.sendMessage(tab.id, { type: 'GET_MEDIA_STATE' });
        if (isMediaState(response)) {
            mediaState = response;
        }
        else if (response && typeof response === 'object') {
            const mediaResponse = response;
            if (isMediaState(mediaResponse.state))
                mediaState = mediaResponse.state;
            if (typeof mediaResponse.pageTitle === 'string')
                mediaTitle = mediaResponse.pageTitle;
        }
    }
    catch {
        // No content script is expected on unsupported sites or before a page has loaded.
    }
    await updateFromActiveTab(mediaState, tab.id, mediaTitle);
}
async function updateFromActiveTab(mediaState = 'unknown', senderTabId, mediaTitle) {
    const tab = await getCurrentActiveTab();
    if (!tab) {
        await storeIfChanged(null);
        return;
    }
    // Ignore late messages from background tabs; they must not clear foreground activity.
    if (senderTabId !== undefined && !isMessageFromActiveTab(tab.id, senderTabId))
        return;
    let effectiveMediaState = mediaState === 'preserve' ? 'unknown' : mediaState;
    if (mediaState === 'preserve') {
        const previous = await browser.storage.local.get(['currentActivity', 'currentTabId']);
        const previousActivity = (previous.currentActivity ?? null);
        const currentSource = createActivityEvent(tab)?.source;
        if (previous.currentTabId === tab.id && previousActivity && previousActivity.source === currentSource) {
            effectiveMediaState = previousActivity.mediaState;
        }
    }
    const event = createActivityEvent(tab, effectiveMediaState, {
        includeTitle: true,
        mediaTitle,
    });
    await storeIfChanged(event, tab.id);
}
// Event listeners are registered synchronously at module startup so the event page
// can be suspended and restarted without losing its wake-up registrations.
browser.runtime.onInstalled.addListener(() => {
    void browser.storage.local.get(['bridgeEnabled', 'bridgeKey']).then(async (settings) => {
        const defaults = {};
        if (typeof settings.bridgeEnabled !== 'boolean')
            defaults.bridgeEnabled = false;
        if (typeof settings.bridgeKey !== 'string')
            defaults.bridgeKey = '';
        if (Object.keys(defaults).length > 0)
            await browser.storage.local.set(defaults);
        await refreshActiveActivity();
        await syncStoredActivity();
    });
});
browser.runtime.onStartup.addListener(() => {
    void refreshActiveActivity().then(syncStoredActivity);
});
browser.tabs.onActivated.addListener(() => {
    void refreshActiveActivity();
});
browser.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
    if (tab.active && (changeInfo.status === 'complete' || typeof changeInfo.url === 'string' || typeof changeInfo.title === 'string')) {
        void injectGenericMediaDetector(tab);
        void updateFromActiveTab('preserve');
    }
});
browser.tabs.onRemoved.addListener(() => {
    void refreshActiveActivity();
});
browser.runtime.onMessage.addListener((message, sender) => {
    if (isMediaMessage(message) && typeof sender.tab?.id === 'number') {
        if (sender.url) {
            try {
                if (isSensitiveHost(new URL(sender.url).hostname))
                    return undefined;
            }
            catch {
                return undefined;
            }
        }
        const mediaTitle = sender.frameId === 0 && typeof message.pageTitle === 'string' ? message.pageTitle : undefined;
        return updateFromActiveTab(message.state, sender.tab.id, mediaTitle);
    }
    if (isBridgeSettingsMessage(message)) {
        if (message.type === 'BRIDGE_SETTINGS_UPDATED') {
            return refreshActiveActivity().then(syncStoredActivity);
        }
        return syncStoredActivity();
    }
    return undefined;
});
