import { isOriginPattern, normalizeOriginPattern } from './core/site-permissions.js';

const HOST_URL = 'http://127.0.0.1:32145';
const enabledInput = document.querySelector<HTMLInputElement>('#bridge-enabled');
const keyInput = document.querySelector<HTMLInputElement>('#pairing-key');
const revealButton = document.querySelector<HTMLButtonElement>('#reveal-key');
const saveButton = document.querySelector<HTMLButtonElement>('#save-settings');
const healthButton = document.querySelector<HTMLButtonElement>('#check-health');
const statusElement = document.querySelector<HTMLElement>('#status');
const siteHostInput = document.querySelector<HTMLInputElement>('#site-host');
const addSiteButton = document.querySelector<HTMLButtonElement>('#add-site');
const siteOriginList = document.querySelector<HTMLElement>('#site-origin-list');
const siteCount = document.querySelector<HTMLElement>('#site-count');

type BridgeSettings = {
  bridgeEnabled?: boolean;
  bridgeKey?: string;
  bridgeStatus?: { message?: string; ok?: boolean; state?: string };
  siteOrigins?: string[];
};

function showStatus(message: string, kind: 'neutral' | 'success' | 'warning' | 'error' = 'neutral'): void {
  if (!statusElement) return;
  statusElement.textContent = message;
  statusElement.dataset.kind = kind;
}

async function loadSettings(): Promise<void> {
  const settings = await browser.storage.local.get([
    'bridgeEnabled', 'bridgeKey', 'bridgeStatus', 'siteOrigins',
  ]) as BridgeSettings;
  if (enabledInput) enabledInput.checked = settings.bridgeEnabled === true;
  if (keyInput) keyInput.value = typeof settings.bridgeKey === 'string' ? settings.bridgeKey : '';
  await renderSiteOrigins(Array.isArray(settings.siteOrigins) ? settings.siteOrigins : []);
  const currentStatus = settings.bridgeStatus;
  if (currentStatus?.message) {
    showStatus(currentStatus.message, currentStatus.ok ? 'success' : currentStatus.state === 'disabled' ? 'neutral' : 'warning');
  }
}

async function saveSettings(): Promise<void> {
  if (!enabledInput || !keyInput) return;
  const bridgeKey = keyInput.value.trim();
  await browser.storage.local.set({ bridgeEnabled: enabledInput.checked, bridgeKey });
  if (enabledInput.checked && !bridgeKey) {
    showStatus('Settings saved, but the bridge is not paired. Copy the pairing key from the Android app.', 'warning');
    await browser.runtime.sendMessage({ type: 'BRIDGE_SETTINGS_UPDATED' });
    return;
  }
  const result = await browser.runtime.sendMessage({ type: 'BRIDGE_SETTINGS_UPDATED' }) as { message?: string; state?: string; ok?: boolean };
  showStatus(result?.message ?? 'Settings saved. Only the active browser tab can publish activity.', result?.ok ? 'success' : 'neutral');
}

async function renderSiteOrigins(origins: string[]): Promise<void> {
  if (!siteOriginList || !siteCount) return;
  const valid = [...new Set(origins.filter(isOriginPattern))].sort();
  const checks = await Promise.all(valid.map(async (origin) => {
    try {
      const granted = await browser.permissions.contains({ origins: [origin] });
      return { origin, granted };
    } catch {
      return { origin, granted: false };
    }
  }));
  siteOriginList.replaceChildren();
  const active = checks.filter((item) => item.granted);
  siteCount.textContent = `${active.length} ACTIVE`;
  if (checks.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = 'No extra website permissions. YouTube’s built-in detector remains available.';
    siteOriginList.append(empty);
    return;
  }
  for (const item of checks) {
    const row = document.createElement('div');
    row.className = 'site-row';
    const info = document.createElement('div');
    info.className = 'site-domain';
    const originText = document.createElement('span');
    originText.textContent = item.origin.replace(/\/\*$/, '');
    const state = document.createElement('small');
    state.className = 'site-state';
    state.textContent = item.granted ? 'PERMISSION ACTIVE' : 'REVOKED IN FIREFOX';
    info.append(originText, state);
    const remove = document.createElement('button');
    remove.className = 'site-remove';
    remove.type = 'button';
    remove.textContent = 'REVOKE';
    remove.disabled = !item.granted;
    remove.setAttribute('aria-label', `Revoke website permission for ${item.origin}`);
    remove.addEventListener('click', () => { void removeSiteOrigin(item.origin); });
    row.append(info, remove);
    siteOriginList.append(row);
  }
}

async function addSiteOrigin(): Promise<void> {
  if (!siteHostInput || !addSiteButton) return;
  let origin: string;
  try {
    origin = normalizeOriginPattern(siteHostInput.value);
  } catch (error) {
    showStatus(error instanceof Error ? error.message : 'Invalid website domain.', 'error');
    return;
  }
  if (addSiteButton.disabled) return;
  addSiteButton.disabled = true;
  try {
    // Keep this permission request directly in the button gesture; do not request both wildcard schemes.
    const granted = await browser.permissions.request({ origins: [origin] });
    if (!granted) {
      showStatus(`Firefox did not grant access to ${origin.replace(/\/\*$/, '')}. No other sites were changed.`, 'warning');
      return;
    }
    const settings = await browser.storage.local.get('siteOrigins') as { siteOrigins?: unknown };
    const existing = Array.isArray(settings.siteOrigins) ? settings.siteOrigins.filter(isOriginPattern) : [];
    const updated = [...new Set([...existing, origin])];
    await browser.storage.local.set({ siteOrigins: updated });
    await browser.runtime.sendMessage({ type: 'BRIDGE_SETTINGS_UPDATED' });
    siteHostInput.value = '';
    await renderSiteOrigins(updated);
    showStatus(`Website access enabled for ${origin.replace(/\/\*$/, '')}. The detector will run only on this active, non-sensitive site.`, 'success');
  } catch (error) {
    const reason = error instanceof Error && error.message ? ` (${error.message})` : '';
    showStatus(`Firefox could not grant ${origin.replace(/\/\*$/, '')}${reason}. Check the add-on's site access in Firefox Settings.`, 'error');
  } finally {
    addSiteButton.disabled = false;
  }
}

async function removeSiteOrigin(origin: string): Promise<void> {
  try {
    await browser.permissions.remove({ origins: [origin] });
    const settings = await browser.storage.local.get('siteOrigins') as { siteOrigins?: unknown };
    const existing = Array.isArray(settings.siteOrigins) ? settings.siteOrigins.filter(isOriginPattern) : [];
    const updated = existing.filter((item) => item !== origin);
    await browser.storage.local.set({ siteOrigins: updated });
    await browser.runtime.sendMessage({ type: 'BRIDGE_SETTINGS_UPDATED' });
    await renderSiteOrigins(updated);
    showStatus(`Website access revoked for ${origin.replace(/\/\*$/, '')}.`, 'success');
  } catch (error) {
    const reason = error instanceof Error && error.message ? ` (${error.message})` : '';
    showStatus(`Could not revoke website access${reason}.`, 'error');
  }
}

async function checkHealth(): Promise<void> {
  if (healthButton) healthButton.disabled = true;
  showStatus('Checking 127.0.0.1:32145…');
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(`${HOST_URL}/v1/health`, {
      method: 'GET', cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer', signal: controller.signal,
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const health = await response.json() as { ok?: boolean; apiVersion?: number; service?: string; bridgeState?: string; discordSdkEnabled?: boolean };
    if (health.ok !== true || health.apiVersion !== 1) throw new Error('Unexpected local bridge response');
    const sdk = health.discordSdkEnabled ? 'Discord SDK enabled' : 'Preview build: Discord SDK not configured';
    showStatus(`${health.service}: ${health.bridgeState}. ${sdk}. Health check does not verify the pairing key.`, 'success');
  } catch (error) {
    const message = error instanceof Error && error.name === 'AbortError'
      ? 'Android host did not respond within five seconds.'
      : 'Cannot reach Android host. Open Gecko Presence and make sure Local Bridge is listening.';
    showStatus(message, 'error');
  } finally {
    clearTimeout(timeoutId);
    if (healthButton) healthButton.disabled = false;
  }
}

revealButton?.addEventListener('click', () => {
  if (!keyInput || !revealButton) return;
  const reveal = keyInput.type === 'password';
  keyInput.type = reveal ? 'text' : 'password';
  revealButton.textContent = reveal ? 'HIDE' : 'SHOW';
});
saveButton?.addEventListener('click', () => { void saveSettings().catch(() => showStatus('Could not save extension settings.', 'error')); });
healthButton?.addEventListener('click', () => { void checkHealth(); });
addSiteButton?.addEventListener('click', () => { void addSiteOrigin(); });
void loadSettings().catch(() => showStatus('Could not load extension settings.', 'error'));
