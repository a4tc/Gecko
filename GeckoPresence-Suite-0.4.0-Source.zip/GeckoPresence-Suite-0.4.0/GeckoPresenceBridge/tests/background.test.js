import test from 'node:test';
import assert from 'node:assert/strict';

let moduleRun = 0;

async function loadBackgroundWithMock(initialTabs = [], mediaStates = {}, initialStorage = {}) {
  const storage = { ...initialStorage };
  const listeners = {};
  const requests = [];
  const injections = [];
  const permissionChecks = [];
  let tabs = initialTabs;
  globalThis.fetch = async (url, options = {}) => {
    requests.push({ url: String(url), options });
    return {
      ok: true,
      status: 202,
      json: async () => ({ ok: true, accepted: true }),
    };
  };

  globalThis.browser = {
    tabs: {
      query: async () => tabs,
      executeScript: async (tabId, details) => { injections.push({ tabId, details }); return []; },
      sendMessage: async (tabId, message) => {
        if (message?.type === 'GET_MEDIA_STATE') {
          const state = mediaStates[tabId] ?? 'unknown';
          if (state instanceof Error) throw state;
          return state;
        }
        return undefined;
      },
      onActivated: { addListener: (listener) => { listeners.activated = listener; } },
      onUpdated: { addListener: (listener) => { listeners.updated = listener; } },
      onRemoved: { addListener: (listener) => { listeners.removed = listener; } },
    },
    storage: {
      local: {
        get: async (keys) => {
          const list = Array.isArray(keys) ? keys : [keys];
          return Object.fromEntries(list.map((key) => [key, storage[key]]));
        },
        set: async (values) => { Object.assign(storage, values); },
      },
    },
    permissions: {
      contains: async (permission) => { permissionChecks.push(permission); return true; },
      request: async () => true,
      remove: async () => true,
    },
    runtime: {
      onInstalled: { addListener: (listener) => { listeners.installed = listener; } },
      onStartup: { addListener: (listener) => { listeners.startup = listener; } },
      onMessage: { addListener: (listener) => { listeners.message = listener; } },
    },
  };

  await import(`../extension/background.js?test=${++moduleRun}`);
  return { storage, listeners, requests, injections, permissionChecks, setTabs: (nextTabs) => { tabs = nextTabs; } };
}

test('registers event listeners synchronously and stores active-tab activity', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 5, active: true, url: 'https://example.com/private/path?token=x', title: 'Private page' },
  ]);

  assert.equal(typeof mock.listeners.activated, 'function');
  assert.equal(typeof mock.listeners.updated, 'function');
  assert.equal(typeof mock.listeners.message, 'function');
  assert.equal(typeof mock.listeners.startup, 'function');

  mock.listeners.activated({ tabId: 5, windowId: 1 });
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(mock.storage.currentActivity.source, 'example.com');
  assert.equal(mock.storage.currentActivity.pageTitle, undefined);
  assert.equal(JSON.stringify(mock.storage.currentActivity).includes('token=x'), false);
});

test('ignores media messages from a background tab without clearing foreground activity', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 5, active: true, url: 'https://example.com/', title: 'Current tab' },
    { id: 6, active: false, url: 'https://www.youtube.com/watch?v=background' },
  ]);

  mock.listeners.activated({ tabId: 5, windowId: 1 });
  await new Promise((resolve) => setImmediate(resolve));
  const before = mock.storage.currentActivity;

  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'playing' },
    { tab: { id: 6 } },
  );

  assert.deepEqual(mock.storage.currentActivity, before);
});

test('accepts media transitions from the active tab', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 5, active: true, url: 'https://www.youtube.com/watch?v=video' },
  ]);

  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'playing' },
    { tab: { id: 5 } },
  );

  assert.equal(mock.storage.currentActivity.mediaState, 'playing');
  assert.equal(mock.storage.currentActivity.details, 'Watching');
});


test('preserves playing state when the active tab title updates', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 5, active: true, url: 'https://www.youtube.com/watch?v=video', title: 'Old title' },
  ]);

  mock.listeners.activated({ tabId: 5, windowId: 1 });
  await new Promise((resolve) => setImmediate(resolve));
  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'playing' },
    { tab: { id: 5 } },
  );

  mock.listeners.updated(5, { title: 'New title' }, {
    id: 5, active: true, url: 'https://www.youtube.com/watch?v=video', title: 'New title',
  });
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(mock.storage.currentActivity.mediaState, 'playing');
});


test('restores the existing media state when returning to a playing tab', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 5, active: true, url: 'https://www.youtube.com/watch?v=video' },
  ], { 5: 'playing' });

  mock.listeners.activated({ tabId: 5, windowId: 1 });
  await new Promise((resolve) => setImmediate(resolve));

  assert.equal(mock.storage.currentActivity.mediaState, 'playing');
  assert.equal(mock.storage.currentActivity.details, 'Watching');
});


test('sends the active-site activity to the paired Android host', async () => {
  const mock = await loadBackgroundWithMock(
    [{ id: 5, active: true, url: 'https://www.youtube.com/watch?v=private', title: 'Private video' }],
    { 5: 'playing' },
    { bridgeEnabled: true, bridgeKey: 'pairing-secret' },
  );

  mock.listeners.activated({ tabId: 5, windowId: 1 });
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(mock.requests.length, 1);
  assert.equal(mock.requests[0].url, 'http://127.0.0.1:32145/v1/activity');
  assert.equal(mock.requests[0].options.method, 'POST');
  assert.equal(mock.requests[0].options.headers['X-GPB-Key'], 'pairing-secret');
  const payload = JSON.parse(mock.requests[0].options.body);
  assert.equal(payload.source, 'youtube.com');
  assert.equal(payload.name, 'YouTube');
  assert.equal(payload.details, 'Watching');
  assert.equal(payload.mediaState, 'playing');
  assert.equal(payload.state, 'Private video');
  assert.equal('url' in payload, false);
  assert.equal(JSON.stringify(payload).includes('private'), false);
  assert.equal(JSON.stringify(payload).includes('pairing-secret'), false);
  assert.equal(Number.isInteger(payload.startTimestamp), true);
});

test('clears the Android activity when the active tab is not a web page', async () => {
  const mock = await loadBackgroundWithMock(
    [{ id: 8, active: true, url: 'about:config' }],
    {},
    { bridgeEnabled: true, bridgeKey: 'pairing-secret' },
  );

  mock.listeners.activated({ tabId: 8, windowId: 1 });
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(mock.requests.length, 1);
  assert.equal(mock.requests[0].url, 'http://127.0.0.1:32145/v1/clear');
  assert.equal(mock.requests[0].options.headers['X-GPB-Key'], 'pairing-secret');
  assert.equal(mock.requests[0].options.body, '{}');
});

test('does not contact the Android host when bridge pairing is not enabled', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 3, active: true, url: 'https://example.com/' },
  ]);

  mock.listeners.activated({ tabId: 3, windowId: 1 });
  await new Promise((resolve) => setTimeout(resolve, 0));

  assert.equal(mock.requests.length, 0);
});

test('resyncs the current activity after bridge settings are saved', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 2, active: true, url: 'https://www.twitch.tv/example' },
  ]);

  mock.listeners.activated({ tabId: 2, windowId: 1 });
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.equal(mock.requests.length, 0);

  mock.storage.bridgeEnabled = true;
  mock.storage.bridgeKey = 'new-pairing-key';
  await mock.listeners.message({ type: 'BRIDGE_SETTINGS_UPDATED' }, {});

  assert.equal(mock.requests.length, 1);
  assert.equal(mock.requests[0].url, 'http://127.0.0.1:32145/v1/activity');
  assert.equal(mock.requests[0].options.headers['X-GPB-Key'], 'new-pairing-key');
  assert.equal(JSON.parse(mock.requests[0].options.body).source, 'twitch.tv');
});


test('injects generic media detection in all permitted frames of the active tab only', async () => {
  const mock = await loadBackgroundWithMock(
    [{ id: 31, active: true, url: 'https://www.idlixplus.net/watch/123' }],
    {},
    {},
  );
  mock.listeners.activated({ tabId: 31, windowId: 1 });
  await new Promise((resolve) => setTimeout(resolve, 0));
  assert.deepEqual(mock.permissionChecks[0], { origins: ['https://*.idlixplus.net/*'] });
  assert.equal(mock.injections.length, 1);
  assert.equal(mock.injections[0].tabId, 31);
  assert.equal(mock.injections[0].details.allFrames, true);
  assert.equal(mock.storage.currentActivity.source, 'idlixplus.net');
});


test('restores browsing presence when the active browser page becomes visible again', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 42, active: true, url: 'https://www.idlixplus.net/watch/123' },
  ]);

  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'unknown' },
    { tab: { id: 42 }, url: 'https://www.idlixplus.net/watch/123' },
  );

  assert.equal(mock.storage.currentActivity.source, 'idlixplus.net');
  assert.equal(mock.storage.currentActivity.mediaState, 'unknown');
  assert.equal(mock.storage.currentActivity.details, 'Browsing');
});

test('ignores media messages originating inside a sensitive embedded frame', async () => {
  const mock = await loadBackgroundWithMock([
    { id: 32, active: true, url: 'https://example-streaming-site.net/watch' },
  ]);
  mock.listeners.activated({ tabId: 32, windowId: 1 });
  await new Promise((resolve) => setImmediate(resolve));
  const before = mock.storage.currentActivity;
  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'playing' },
    { tab: { id: 32 }, url: 'https://mybca.bca.co.id/login', frameId: 4 },
  );
  assert.deepEqual(mock.storage.currentActivity, before);
});


test('accepts a title extracted by the top-level IDLix document and forwards it while watching', async () => {
  const mock = await loadBackgroundWithMock(
    [{ id: 74, active: true, url: 'https://www.idlixplus.net/movie/slug' }],
    {},
    { bridgeEnabled: true, bridgeKey: 'pairing-secret' },
  );

  await mock.listeners.message(
    { type: 'MEDIA_STATE', state: 'playing', pageTitle: 'Sample Film (2026) - IDLix' },
    { tab: { id: 74 }, url: 'https://www.idlixplus.net/movie/slug', frameId: 0 },
  );

  assert.equal(mock.storage.currentActivity.details, 'Watching');
  assert.equal(mock.storage.currentActivity.pageTitle, 'Sample Film (2026)');
  const payload = JSON.parse(mock.requests.at(-1).options.body);
  assert.equal(payload.details, 'Watching');
  assert.equal(payload.state, 'Sample Film (2026)');
  assert.equal(payload.source, 'idlixplus.net');
  assert.equal('url' in payload, false);
});
